import { NextRequest, NextResponse } from 'next/server';
import { verifyServerAdmin } from '@/lib/serverAdminAuth';
import { NvidiaProvider, ChatMessagePayload, MultimodalContentPart } from '@/lib/ai/providers/nvidia';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const auth = verifyServerAdmin(req);
  if (!auth.authorized) {
    return NextResponse.json(
      { success: false, error: 'Acesso não autorizado.', errorCode: 'UNAUTHORIZED' },
      { status: 401 }
    );
  }

  try {
    const body = await req.json();
    const {
      model = 'z-ai/glm-5.3',
      prompt = 'Explique brevemente como funciona uma bicicleta elétrica com motor central.',
      imageUrl,
      temperature,
      topP,
      maxTokens,
      enableThinking = true,
      reasoningEffort,
      seed,
      apiFormat = 'chat_completions',
      baseURL,
      apiKey,
    } = body;

    const normalizedModel = NvidiaProvider.normalizeModel(model);

    let messages: ChatMessagePayload[] = [];
    if (imageUrl && (normalizedModel === 'google/gemma-4-31b-it' || normalizedModel === 'moonshotai/kimi-k3')) {
      const parts: MultimodalContentPart[] = [
        { type: 'text', text: prompt || 'What is in this image?' },
        { type: 'image_url', image_url: { url: imageUrl } },
      ];
      messages = [{ role: 'user', content: parts }];
    } else {
      messages = [{ role: 'user', content: prompt }];
    }

    if (apiFormat === 'responses_api') {
      // Assinatura posicional: `executeResponsesApi(model, prompt, systemPrompt?, options?)`.
      // A chamada anterior passava um objeto único, então `model` chegava
      // como `{...}` e o provider normalizeva um modelo inexistente — este
      // endpoint era o botão "testar conexão" do painel de IA.
      const respResult = await NvidiaProvider.executeResponsesApi(
        normalizedModel,
        prompt,
        undefined,
        {
          maxTokens,
          temperature,
          topP,
          baseURL,
          apiKey,
        }
      );

      return NextResponse.json({
        success: true,
        apiFormat: 'responses_api',
        modelUsed: normalizedModel,
        result: {
          text: respResult.text,
          reasoningContent: respResult.reasoningContent,
          usage: respResult.usage,
        },
      });
    }

    // Idem: `chatCompletion(model, messages, options)` é posicional.
    const result = await NvidiaProvider.chatCompletion(normalizedModel, messages, {
      temperature,
      topP,
      maxTokens,
      enableThinking,
      reasoningEffort,
      seed,
      baseURL,
      apiKey,
    });

    return NextResponse.json({
      success: true,
      apiFormat: 'chat_completions',
      modelUsed: normalizedModel,
      result: {
        text: result.text,
        reasoningContent: result.reasoningContent,
        usage: result.usage,
      },
    });
  } catch (err: any) {
    console.error('[NvidiaTestRoute] Erro na execução:', err);
    return NextResponse.json(
      {
        success: false,
        error: err.message || 'Erro ao processar chamada com o modelo NVIDIA.',
        errorCode: 'NVIDIA_EXECUTION_ERROR',
      },
      { status: 500 }
    );
  }
}
