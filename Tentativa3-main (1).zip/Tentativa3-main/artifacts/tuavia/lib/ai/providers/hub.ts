/**
 * lib/ai/providers/hub.ts
 *
 * Ponto único de chamada ao provedor, com degradação encadeada.
 * Substitui `@/src/ai/providers/ProviderHub`, que não existia.
 *
 * Todo consumidor passa por aqui — assim há um único lugar onde a política de
 * fallback, o rate limit, o circuit breaker e a telemetria são aplicados.
 */

import { NvidiaProvider, ProviderError } from '@/lib/ai/providers/nvidia';
import { AIExecutionLogger } from '@/lib/ai/telemetry';
import type { Priority } from '@/lib/ai/rateLimiter';
import type {
  AIModelId,
  ChatMessagePayload,
  MultimodalContentPart,
  ProviderResult,
} from '@/lib/ai/types';

export type { ProviderResult, ChatMessagePayload, MultimodalContentPart };

export interface ExecuteWithFallbackOptions {
  /** Identificador da operação, usado na telemetria e nos logs. */
  taskName: string;
  primaryModel: AIModelId;
  fallbackModel?: AIModelId;
  tertiaryModel?: AIModelId;
  messages: Array<string | ChatMessagePayload | MultimodalContentPart[]>;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  timeoutMs?: number;
  priority?: Priority;
  enableThinking?: boolean;
  reasoningEffort?: 'low' | 'medium' | 'high';
  signal?: AbortSignal;
  /** Resposta bruta, sem os campos de degradação. */
  raw?: boolean;
}

class ProviderHubClass {
  /** Modelo padrão do projeto, usado quando nada é especificado. */
  static readonly DEFAULT = 'nvidia/llama-3.1-nemotron-70b-instruct';

  /**
   * Modelo por papel, para quem precisa escolher o primário e o fallback em vez
   * de repetir o mesmo par de modelos em cada chamador.
   *
   * Existia um consumo de `ProviderHub.DEFAULT_MODELS.orchestrator` sem que
   * este mapa existisse: a leitura era `undefined` e a rota do radar caía em
   * `TypeError` antes de falar com o provedor.
   */
  static readonly DEFAULT_MODELS = {
    orchestrator: 'nvidia/llama-3.1-nemotron-70b-instruct',
    /** Raciocínio mais forte, para tarefa que exige raciocínio longo. */
    reasoning: 'nvidia/nemotron-3-ultra-550b-a55b',
    /** Texto corrido e rápido, para resumo e classificação. */
    fast: 'nvidia/llama-3.1-nemotron-70b-instruct',
  } as const;

  /**
   * Tenta primary -> fallback -> tertiary. Só cai para o próximo modelo em
   * falha transitória (timeout, 5xx, 429, cota). Erro de chave inválida ou de
   * prompt é permanente e propaga imediatamente.
   */
  static async executeWithFallback(
    options: ExecuteWithFallbackOptions
  ): Promise<ProviderResult> {
    const chain = [options.primaryModel, options.fallbackModel, options.tertiaryModel].filter(
      (model): model is string => Boolean(model && model.trim())
    );

    if (chain.length === 0) {
      throw new ProviderError('Nenhum modelo informado para executeWithFallback.', {
        errorCode: 'INVALID_MODEL',
      });
    }

    let lastError: ProviderError | null = null;

    for (let index = 0; index < chain.length; index += 1) {
      const model = chain[index];
      if (!model) continue;

      try {
        const result = await NvidiaProvider.chatCompletion(model, options.messages, {
          temperature: options.temperature,
          maxTokens: options.maxTokens,
          topP: options.topP,
          timeoutMs: options.timeoutMs,
          priority: options.priority,
          enableThinking: options.enableThinking,
          reasoningEffort: options.reasoningEffort,
          signal: options.signal,
        });

        if (options.raw) return result;

        return {
          ...result,
          degraded: index > 0,
          degradedReason:
            index > 0 ? `Fallback para ${model} após falha em ${chain[index - 1]}.` : undefined,
        };
      } catch (error) {
        const providerError =
          error instanceof ProviderError
            ? error
            : new ProviderError(error instanceof Error ? error.message : String(error), {
                errorCode: 'UNKNOWN',
                retryable: true,
              });

        lastError = providerError;
        console.warn(
          `[ProviderHub] ${options.taskName}: ${model} falhou (${providerError.errorCode}${
            providerError.status ? `/${providerError.status}` : ''
          }).`
        );

        if (!providerError.retryable) throw providerError;
      }
    }

    throw (
      lastError ??
      new ProviderError(`Falha em todos os modelos para ${options.taskName}.`, {
        errorCode: 'ALL_MODELS_FAILED',
        retryable: true,
      })
    );
  }

  /** Chamada única, sem fallback. Usada por diagnóstico e pelo playground. */
  static async execute(options: ExecuteWithFallbackOptions): Promise<ProviderResult> {
    return ProviderHubClass.executeWithFallback({
      ...options,
      fallbackModel: undefined,
      tertiaryModel: undefined,
    });
  }

  /** Embeddings. Usa o endpoint dedicado e devolve o vetor bruto. */
  static async embed(input: string, model = 'nvidia/nemotron-3-embed-1b'): Promise<number[]> {
    const keys = NvidiaProvider.getApiKeys();
    if (keys.length === 0) {
      throw new ProviderError('NVIDIA_API_KEY não configurada.', { errorCode: 'API_KEY_MISSING' });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30_000);
    try {
      const response = await fetch(`${NvidiaProvider.getBaseUrl()}/embeddings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${keys[0]}` },
        body: JSON.stringify({ model, input: input.slice(0, 8000), input_type: 'passage' }),
        signal: controller.signal,
      });
      if (!response.ok) {
        throw new ProviderError(`Embeddings ${response.status}.`, {
          status: response.status,
          errorCode: 'EMBEDDING_FAILED',
          retryable: response.status >= 500 || response.status === 429,
        });
      }
      const payload = (await response.json()) as any;
      const vector = payload?.data?.[0]?.embedding;
      if (!Array.isArray(vector)) {
        throw new ProviderError('Resposta de embeddings sem vetor.', { errorCode: 'EMPTY_EMBEDDING' });
      }
      return vector as number[];
    } finally {
      clearTimeout(timeout);
    }
  }

  /** Registra uma execução na telemetria (caminhos que não passam por chatCompletion). */
  static log(entry: Parameters<typeof AIExecutionLogger.log>[0]): void {
    AIExecutionLogger.log(entry);
  }
}

export const ProviderHub = ProviderHubClass;
