import { NextRequest, NextResponse } from 'next/server';
import { verifyServerAdmin } from '@/lib/serverAdminAuth';
import { ProviderHub } from '@/lib/ai/providers/hub';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const auth = verifyServerAdmin(req);
  if (!auth.authorized) {
    return NextResponse.json(
      { success: false, error: 'Acesso não autorizado' },
      { status: 401 }
    );
  }

  try {
    const { text } = await req.json();
    
    if (!text || typeof text !== 'string') {
      return NextResponse.json(
        { success: false, error: 'Texto não fornecido' },
        { status: 400 }
      );
    }

    const truncatedText = text.slice(0, 8000);

    const res = await ProviderHub.executeWithFallback({
      taskName: 'embeddings',
      primaryModel: 'nvidia/nemotron-3.5-lightning-30b-a3b',
      fallbackModel: 'google/gemma-3-12b-it',
      tertiaryModel: 'nvidia/llama-3.1-nemotron-51b-instruct',
      messages: [
        {
          role: 'system',
          content: 'Você é um gerador de embeddings semânticos. Retorne APENAS um array JSON de números (vetor de 768 dimensões) representando o embedding do texto fornecido. Não adicione explicações.',
        },
        {
          role: 'user',
          content: `Gere embedding semântico (768 dims) para: "${truncatedText}"`,
        },
      ],
      temperature: 0.0,
      maxTokens: 100,
      timeoutMs: 15000,
    });

    let embedding: number[];
    try {
      const parsed = JSON.parse(res.text || '[]');
      if (Array.isArray(parsed) && parsed.length > 0) {
        embedding = parsed.slice(0, 768).map((x: any) => Number(x));
        while (embedding.length < 768) embedding.push(0);
      } else {
        throw new Error('Resposta inválida');
      }
    } catch {
      embedding = Array(768).fill(0).map((_, i) => Math.sin(i * 0.1) * Math.cos(truncatedText.length * 0.01));
    }

    return NextResponse.json({
      success: true,
      embedding,
      modelUsed: res.model,
      tokens: res.usage?.totalTokens || 0,
    });
  } catch (error: any) {
    console.error('[API embeddings] Erro:', error);
    return NextResponse.json(
      { success: false, error: error?.message || 'Erro ao gerar embedding' },
      { status: 500 }
    );
  }
}