import { NextRequest, NextResponse } from 'next/server';
import { verifyServerAdmin } from '@/lib/serverAdminAuth';
import { ProviderHub } from '@/lib/ai/providers/hub';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const auth = verifyServerAdmin(req);
  if (!auth.authorized) {
    return NextResponse.json(
      { success: false, error: 'Acesso não autorizado' },
      { status: 401 }
    );
  }

  try {
    const { query, candidates } = await req.json();
    
    if (!query || !Array.isArray(candidates) || candidates.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Query e candidatos são obrigatórios' },
        { status: 400 }
      );
    }

    const candidateTexts = candidates.map((c, i) => `${i + 1}. ${c.text}\nEvidência: ${c.evidence || 'N/A'}`).join('\n\n');

    const res = await ProviderHub.executeWithFallback({
      taskName: 'rerank',
      primaryModel: 'nvidia/llama-3.1-nemotron-70b-instruct',
      fallbackModel: 'nvidia/nemotron-3-ultra-550b-a55b',
      tertiaryModel: 'mistralai/mixtral-8x22b-v0.1',
      messages: [
        {
          role: 'system',
          content: `Você é um reranker semântico especializado em fichas técnicas de e-bikes.
Dada uma query do usuário e uma lista de candidatos (cada um com ID, texto e evidência), atribua um score de relevância de 0.0 a 1.0 para cada candidato.

Retorne APENAS JSON válido no formato:
{
  "results": [
    { "id": "candidate_id", "score": 0.95 },
    { "id": "candidate_id", "score": 0.82 }
  ]
}`,
        },
        {
          role: 'user',
          content: `Query: "${query}"

Candidatos:
${candidateTexts}

Retorne scores de relevância (0.0 a 1.0).`,
        },
      ],
      temperature: 0.0,
      maxTokens: 1000,
      timeoutMs: 20000,
    });

    let results: Array<{ id: string; score: number }> = [];
    try {
      const parsed = JSON.parse(res.text || '{}');
      if (parsed.results && Array.isArray(parsed.results)) {
        results = parsed.results;
      }
    } catch {
      console.warn('[Rerank] Falha ao parsear resposta, usando scores padrão');
      results = candidates.map((c, i) => ({ id: c.id || `cand_${i}`, score: 0.5 - i * 0.05 }));
    }

    return NextResponse.json({
      success: true,
      results,
      modelUsed: res.model,
    });
  } catch (error: any) {
    console.error('[API rerank] Erro:', error);
    return NextResponse.json(
      { success: false, error: error?.message || 'Erro no rerank' },
      { status: 500 }
    );
  }
}