/**
 * CATÁLOGO REDUZIDO DE MODELOS NVIDIA NIM (5 Modelos Selecionados)
 * ============================================================
 * Seleção otimizada para TuaVia: Chat PT-BR, Reasoning, Multimodal Vision, Open Compat
 * Fonte: https://integrate.api.nvidia.com/v1/models
 */

export type NvidiaModelId =
  // --- Chat / PT-BR Balanced ---
  | 'z-ai/glm-5.3'
  // --- Reasoning / Long Context (Streaming + Thinking) ---
  | 'nvidia/nemotron-3-ultra-550b-a55b'
  // --- Multimodal Vision ---
  | 'google/gemma-4-31b-it'
  | 'moonshotai/kimi-k3'
  // --- Open Compat / Reasoning ---
  | 'openai/gpt-oss-20b';

export interface NvidiaModelInfo {
  id: NvidiaModelId;
  name: string;
  category: 'chat' | 'reasoning' | 'multimodal';
  contextWindow: number;
  maxOutputTokens: number;
  multimodal: boolean;
  /** Uso recomendado no TuaVia */
  bestFor: string[];
}

export const NVIDIA_MODELS: Record<NvidiaModelId, NvidiaModelInfo> = {
  'z-ai/glm-5.3': {
    id: 'z-ai/glm-5.3',
    name: 'GLM 5.3',
    category: 'chat',
    contextWindow: 131072,
    maxOutputTokens: 16384,
    multimodal: false,
    bestFor: ['chat', 'pt-br', 'balanced', 'extraction', 'classification', 'seo', 'writer'],
  },
  'nvidia/nemotron-3-ultra-550b-a55b': {
    id: 'nvidia/nemotron-3-ultra-550b-a55b',
    name: 'Nemotron 3 Ultra 550B',
    category: 'reasoning',
    contextWindow: 131072,
    maxOutputTokens: 16384,
    multimodal: false,
    bestFor: ['reasoning', 'planner', 'researcher', 'auditor', 'seo', 'verdict', 'streaming-thinking'],
  },
  'google/gemma-4-31b-it': {
    id: 'google/gemma-4-31b-it',
    name: 'Gemma 4 31B IT',
    category: 'multimodal',
    contextWindow: 8192,
    maxOutputTokens: 8192,
    multimodal: true,
    bestFor: ['vision', 'image-analysis', 'multimodal', 'image_research'],
  },
  'moonshotai/kimi-k3': {
    id: 'moonshotai/kimi-k3',
    name: 'Kimi K3',
    category: 'multimodal',
    contextWindow: 131072,
    maxOutputTokens: 16384,
    multimodal: true,
    bestFor: ['vision', 'image-analysis', 'multimodal', 'reasoning_effort_max', 'comparison'],
  },
  'openai/gpt-oss-20b': {
    id: 'openai/gpt-oss-20b',
    name: 'GPT-OSS 20B',
    category: 'chat',
    contextWindow: 131072,
    maxOutputTokens: 4096,
    multimodal: false,
    bestFor: ['chat', 'fallback', 'reasoning', 'open-compat', 'responses-api'],
  },
};

export const ALL_NVIDIA_MODEL_IDS = Object.keys(NVIDIA_MODELS) as NvidiaModelId[];

/**
 * Modelos usáveis em conversa.
 *
 * O catálogo só declara categorias `chat`, `reasoning` e `multimodal`, então
 * os filtros por `embedding`/`parser` eram comparações impossíveis — e o
 * `EMBEDDING_MODEL_IDS` derivado delas era sempre vazio e não tinha consumidor.
 */
export const CHAT_MODEL_IDS = ALL_NVIDIA_MODEL_IDS;

export function isValidNvidiaModel(id: string): id is NvidiaModelId {
  return id in NVIDIA_MODELS;
}

export function getModelInfo(id: string): NvidiaModelInfo | undefined {
  return isValidNvidiaModel(id) ? NVIDIA_MODELS[id] : undefined;
}

/**
 * Detecta e corrige IDs obsoletos (migrados pela NVIDIA) para o ID real atual.
 * Mapeia apenas para os 5 modelos mantidos.
 */
const LEGACY_ALIASES: Record<string, NvidiaModelId> = {
  // gpt-oss variants
  'openai/gpt-oss-120b': 'openai/gpt-oss-20b',
  'openai/gpt-oss-120b-instruct': 'openai/gpt-oss-20b',
  // GLM variants
  'z-ai/glm-5.2': 'z-ai/glm-5.3',
  'z-ai/glm-5.3-flash': 'z-ai/glm-5.3',
  // Nemotron variants
  'nvidia/nemotron-3-ultra': 'nvidia/nemotron-3-ultra-550b-a55b',
  'nvidia/nemotron-3-super-120b-a12b': 'nvidia/nemotron-3-ultra-550b-a55b',
  'nvidia/nemotron-4-340b-instruct': 'nvidia/nemotron-3-ultra-550b-a55b',
  'nvidia/llama-3.1-nemotron-ultra-253b-v1': 'nvidia/nemotron-3-ultra-550b-a55b',
  // Meta/Llama variants
  'meta/llama-3.1-405b-instruct': 'nvidia/nemotron-3-ultra-550b-a55b',
  'meta/llama-3.1-70b-instruct': 'z-ai/glm-5.3',
  'meta/llama-3.1-8b-instruct': 'z-ai/glm-5.3',
  'meta/llama-3.3-70b-instruct': 'nvidia/nemotron-3-ultra-550b-a55b',
  // Mistral variants
  'mistralai/mixtral-8x22b-instruct': 'moonshotai/kimi-k3',
  'mistralai/mixtral-8x22b-v0.1': 'moonshotai/kimi-k3',
  'mistralai/mistral-nemotron': 'z-ai/glm-5.3',
  // DeepSeek variants
  'deepseek-ai/deepseek-v4.1-flash': 'z-ai/glm-5.3',
  'deepseek-ai/deepseek-v4-flash-0731': 'z-ai/glm-5.3',
  'deepseek-ai/deepseek-v4-pro-0813': 'nvidia/nemotron-3-ultra-550b-a55b',
  'deepseek-ai/deepseek-coder-6.7b-instruct': 'z-ai/glm-5.3',
  // CodeLlama
  'nvidia/codellama-70b-instruct': 'z-ai/glm-5.3',
  'meta/codellama-70b': 'z-ai/glm-5.3',
  // Microsoft Phi
  'microsoft/phi-3.5-moe-instruct': 'z-ai/glm-5.3',
  'microsoft/phi-3-vision-128k-instruct': 'google/gemma-4-31b-it',
  // Moonshot/Kimi variants
  'moonshotai/kimi-k2.6': 'moonshotai/kimi-k3',
  // Google Gemma variants
  'google/gemma-3-12b-it': 'google/gemma-4-31b-it',
  'google/gemma-3-27b-it': 'google/gemma-4-31b-it',
  'google/gemma-4-31b-it': 'google/gemma-4-31b-it',
  'google/diffusiongemma-26b-a4b-it': 'z-ai/glm-5.3',
  // Embeddings (map to chat fallback)
  'nvidia/embed-qa-4': 'z-ai/glm-5.3',
  'nvidia/nemotron-3-embed-1b': 'z-ai/glm-5.3',
  'nvidia/llama-nemotron-embed-vl-1b-v2': 'z-ai/glm-5.3',
  // Parsers (map to chat fallback)
  'nvidia/nemotron-parse': 'z-ai/glm-5.3',
  'nvidia/nemotron-parse-2.0': 'z-ai/glm-5.3',
  // Others
  'openai/gpt-oss-20b': 'openai/gpt-oss-20b',
  'poolside/laguna-xs-2.1': 'z-ai/glm-5.3',
  'meta/muse-glimmer-30b': 'z-ai/glm-5.3',
  'nvidia/api-hub': 'nvidia/nemotron-3-ultra-550b-a55b',
};

export function resolveModelId(id: string): NvidiaModelId {
  if (isValidNvidiaModel(id)) return id;
  const alias = LEGACY_ALIASES[id];
  if (alias) {
    console.warn(
      `[NvidiaCatalog] Modelo obsoleto "${id}" remapeado para "${alias}". ` +
      `Atualize a referência no código.`
    );
    return alias;
  }
  // Fallback seguro: modelo default que existe
  console.warn(`[NvidiaCatalog] Modelo desconhecido "${id}", usando default (z-ai/glm-5.3).`);
  return 'z-ai/glm-5.3';
}

export function getLegacyAliases(): Record<string, NvidiaModelId> {
  return { ...LEGACY_ALIASES };
}